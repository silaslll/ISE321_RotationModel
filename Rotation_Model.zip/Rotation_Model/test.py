num = [10]
blocks = []
for i in range(num[0]):
    blocks.append("Block" + str(i +1 ))

print(blocks)